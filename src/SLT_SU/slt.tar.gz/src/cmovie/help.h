
/* help.c */
int      HelpPrint(char *start, char *finish);
int      HelpMore(char *start, char *finish);
