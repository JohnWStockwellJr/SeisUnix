
#ifndef GRUNGE_H
#define GRUNGE_H

typedef unsigned char *byte;
typedef byte Buffer;

typedef char string[256];
typedef char Message[256];

#endif
